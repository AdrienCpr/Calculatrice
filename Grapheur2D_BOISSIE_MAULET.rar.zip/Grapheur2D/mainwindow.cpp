#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "expressionmodel.h"

#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>

#include <QDoubleSpinBox>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QWidget>
#include <QtCharts/QValueAxis>


static double f(double x, double a, double b, double c) {
    return a*x*x + b*x + c;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // ---- Model
    auto *model = new ExpressionModel(this);

    // ---- View (chart)
    auto *series = new QLineSeries();
    auto *chart  = new QChart();
    chart->addSeries(series);

    // Axe X
    auto *axisX = new QValueAxis();
    axisX->setRange(-20, 20);          // <-- abscisses
    axisX->setTitleText("x");

    // Axe Y
    auto *axisY = new QValueAxis();
    axisY->setRange(-50, 200);         // <-- ordonnées
    axisY->setTitleText("f(x)");

    chart->addAxis(axisX, Qt::AlignBottom);
    chart->addAxis(axisY, Qt::AlignLeft);

    series->attachAxis(axisX);
    series->attachAxis(axisY);

    chart->setTitle("Grapheur 2D - a*x^2 + b*x + c");


    auto *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    // ---- Controls (constantes)
    auto *spinA = new QDoubleSpinBox();
    auto *spinB = new QDoubleSpinBox();
    auto *spinC = new QDoubleSpinBox();

    for (auto *s : {spinA, spinB, spinC}) {
        s->setRange(-1000, 1000);
        s->setDecimals(3);
        s->setSingleStep(2);
    }

    spinA->setValue(model->a());
    spinB->setValue(model->b());
    spinC->setValue(model->c());

    connect(spinA, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            model, &ExpressionModel::setA);
    connect(spinB, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            model, &ExpressionModel::setB);
    connect(spinC, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            model, &ExpressionModel::setC);

    auto recompute = [=]() {
        series->clear();

        double ymin = 1e9;
        double ymax = -1e9;

        for (int i = -200; i <= 200; ++i) {
            double x = i / 10.0;
            double y = f(x, model->a(), model->b(), model->c());
            series->append(x, y);
            ymin = std::min(ymin, y);
            ymax = std::max(ymax, y);
        }

        axisY->setRange(ymin - 1, ymax + 1);
    };


    connect(model, &ExpressionModel::changed, this, recompute);
    recompute();

    // ---- Layout
    auto *form = new QFormLayout();
    form->addRow("a", spinA);
    form->addRow("b", spinB);
    form->addRow("c", spinC);

    auto *controls = new QWidget();
    controls->setLayout(form);

    auto *root = new QWidget();
    auto *hl = new QHBoxLayout(root);
    hl->addWidget(controls);
    hl->addWidget(chartView, 1);

    setCentralWidget(root);
}

MainWindow::~MainWindow()
{
    delete ui;
}
