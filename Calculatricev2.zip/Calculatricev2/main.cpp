#include <iostream>
#include <stack>
#include <vector>
#include <memory>
#include <cctype>

#include "Constante.h"
#include "Variable.h"
#include "TableSymboles.h"

using namespace std;

/*
 Calculatrice NPI - It�ration 2
 - Constantes
 - Variables
 - Table des symboles
 - Op�rateurs + - * /
*/

int main() {
    TableSymboles table;
    stack<Expression*> pile;
    vector<unique_ptr<Expression>> memoire;

    cout << "Calculatrice NPI - Iteration 2" << endl;
    cout << "Exemple : 5 3 + p" << endl;
    cout << "p = calculer, q = quitter" << endl;

    string tok;
    while (cin >> tok) {

        /* Quitter */
        if (tok == "q") break;

        /* Calcul / affichage */
        if (tok == "p") {
            if (pile.size() != 1) {
                cout << "Erreur : expression invalide" << endl;
            } else {
                cout << "Resultat = " << pile.top()->calculer() << endl;
            }

            // R�initialisation pour un nouveau calcul
            while (!pile.empty()) pile.pop();
            memoire.clear();
            continue;
        }

        /* Nombre */
        if (isdigit(tok[0])) {
            memoire.push_back(make_unique<Constante>(stof(tok)));
            pile.push(memoire.back().get());
            continue;
        }

        /* Variable */
        if (isalpha(tok[0])) {
            if (!table.existe(tok)) {
                cout << "Valeur de " << tok << " ? ";
                float v;
                cin >> v;
                table.definir(tok, v);
            }
            memoire.push_back(make_unique<Variable>(tok, &table));
            pile.push(memoire.back().get());
            continue;
        }

        /* OPERATEURS */
        if (tok == "+" || tok == "-" || tok == "*" || tok == "/") {

            if (pile.size() < 2) {
                cout << "Erreur : pas assez d'operandes" << endl;
                continue;
            }

            Expression* b = pile.top(); pile.pop();
            Expression* a = pile.top(); pile.pop();

            float res = 0.0f;

            if (tok == "+") res = a->calculer() + b->calculer();
            if (tok == "-") res = a->calculer() - b->calculer();
            if (tok == "*") res = a->calculer() * b->calculer();
            if (tok == "/") {
                if (b->calculer() == 0) {
                    cout << "Erreur : division par zero" << endl;
                    continue;
                }
                res = a->calculer() / b->calculer();
            }

            memoire.push_back(make_unique<Constante>(res));
            pile.push(memoire.back().get());
            continue;
        }

        /* Token inconnu */
        cout << "Token invalide : " << tok << endl;
    }

    return 0;
}
