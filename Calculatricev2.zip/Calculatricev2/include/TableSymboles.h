#ifndef TABLESYMBOLES_H
#define TABLESYMBOLES_H

#include <unordered_map>
#include <string>

/*
 Table des symboles :
 associe variable -> valeur
*/
class TableSymboles {
    std::unordered_map<std::string, float> table;
public:
    bool existe(const std::string& nom) const;
    void definir(const std::string& nom, float valeur);
    float valeur(const std::string& nom) const;
};

#endif
