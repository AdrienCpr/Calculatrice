#ifndef VARIABLE_H
#define VARIABLE_H

#include "Expression.h"
#include "TableSymboles.h"

class Variable : public Expression {
    std::string nom;
    const TableSymboles* table;
public:
    Variable(const std::string& n, const TableSymboles* t);
    void afficher_classique(ostream& os = cout) override;
    void afficher_npi(ostream& os = cout) override;
    float calculer() override;
};

#endif
