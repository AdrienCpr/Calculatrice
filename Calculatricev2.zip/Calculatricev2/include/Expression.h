#ifndef EXPRESSION_H
#define EXPRESSION_H

#include <iostream>
using namespace std;

/*
 Classe abstraite Expression
 Toutes les expressions en h�ritent
*/
class Expression {
public:
    virtual ~Expression() {}
    virtual void afficher_classique(ostream& os = cout) = 0;
    virtual void afficher_npi(ostream& os = cout) = 0;
    virtual float calculer() = 0;
};

#endif
