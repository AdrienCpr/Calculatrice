#ifndef CONSTANTE_H
#define CONSTANTE_H

#include "Expression.h"

class Constante : public Expression {
    float valeur;
public:
    Constante(float v);
    void afficher_classique(ostream& os = cout) override;
    void afficher_npi(ostream& os = cout) override;
    float calculer() override;
};

#endif
