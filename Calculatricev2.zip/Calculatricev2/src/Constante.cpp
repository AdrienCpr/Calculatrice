#include "Constante.h"

Constante::Constante(float v) : valeur(v) {}

void Constante::afficher_classique(ostream& os) {
    os << valeur;
}

void Constante::afficher_npi(ostream& os) {
    os << valeur;
}

float Constante::calculer() {
    return valeur;
}
