#include "TableSymboles.h"
#include <stdexcept>

bool TableSymboles::existe(const std::string& nom) const {
    return table.find(nom) != table.end();
}

void TableSymboles::definir(const std::string& nom, float valeur) {
    table[nom] = valeur;
}

float TableSymboles::valeur(const std::string& nom) const {
    auto it = table.find(nom);
    if (it == table.end())
        throw std::runtime_error("Variable non d�finie");
    return it->second;
}
