#include "Variable.h"

Variable::Variable(const std::string& n, const TableSymboles* t)
    : nom(n), table(t) {}

void Variable::afficher_classique(ostream& os) {
    os << nom;
}

void Variable::afficher_npi(ostream& os) {
    os << nom;
}

float Variable::calculer() {
    return table->valeur(nom);
}
