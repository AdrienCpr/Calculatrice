#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtDataVisualization/q3dsurface.h>
#include <QtDataVisualization/qsurface3dseries.h>
#include <QtDataVisualization/qsurfacedataproxy.h>

class SurfaceModel;

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;

}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void updateSurface();

private:
    Ui::MainWindow *ui;

    Q3DSurface *m_graph;
    QSurface3DSeries *m_series;
    SurfaceModel *m_model;
};

#endif // MAINWINDOW_H
