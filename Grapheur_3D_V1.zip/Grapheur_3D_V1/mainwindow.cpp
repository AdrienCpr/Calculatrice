#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "surfacemodel.h"

#include <QHBoxLayout>
#include <QVector3D>
#include <cmath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_graph(new Q3DSurface())
    , m_series(new QSurface3DSeries())
    , m_model(new SurfaceModel(this))
{
    ui->setupUi(this);
    ui->spinA->setValue(m_model->a());
    ui->spinB->setValue(m_model->b());
    ui->spinXMin->setValue(m_model->xMin());
    ui->spinXMax->setValue(m_model->xMax());
    ui->spinYMin->setValue(m_model->yMin());
    ui->spinYMax->setValue(m_model->yMax());

    // --- Container du graphe dans graphWidget ---
    QWidget *container = QWidget::createWindowContainer(m_graph, ui->graphWidget);
    container->setMinimumSize(400, 300);

    auto *graphLayout = new QHBoxLayout(ui->graphWidget);
    graphLayout->setContentsMargins(0, 0, 0, 0);
    graphLayout->addWidget(container);

    // --- Série 3D ---
    m_graph->addSeries(m_series);

    // --- Connexions UI → updateSurface ---
    // Vue -> Modèle : les widgets modifient le modèle
    connect(ui->spinA,    SIGNAL(valueChanged(double)), m_model, SLOT(setA(double)));
    connect(ui->spinB,    SIGNAL(valueChanged(double)), m_model, SLOT(setB(double)));
    connect(ui->spinXMin, SIGNAL(valueChanged(double)), m_model, SLOT(setXMin(double)));
    connect(ui->spinXMax, SIGNAL(valueChanged(double)), m_model, SLOT(setXMax(double)));
    connect(ui->spinYMin, SIGNAL(valueChanged(double)), m_model, SLOT(setYMin(double)));
    connect(ui->spinYMax, SIGNAL(valueChanged(double)), m_model, SLOT(setYMax(double)));

    // Modèle -> Vue : quand un paramètre change, on recalcule la surface
    connect(m_model, SIGNAL(parametersChanged()),
            this, SLOT(updateSurface()));

    // Première génération
    updateSurface();
}

void MainWindow::updateSurface()
{
    // 1) Lire les paramètres dans le modèle (plus dans l'UI)
    //double a    = m_model->a();
    //double b    = m_model->b();
    double xMin = m_model->xMin();
    double xMax = m_model->xMax();
    double yMin = m_model->yMin();
    double yMax = m_model->yMax();

    const int stepsX = 50;
    const int stepsY = 50;

    if (xMax == xMin)
        xMax = xMin + 0.01;
    if (yMax == yMin)
        yMax = yMin + 0.01;

    // 2) Génération des données
    QSurfaceDataArray *dataArray = new QSurfaceDataArray;
    dataArray->reserve(stepsY);

    const float stepX = float((xMax - xMin) / double(stepsX - 1));
    const float stepY = float((yMax - yMin) / double(stepsY - 1));

    for (int j = 0; j < stepsY; ++j) {
        QSurfaceDataRow *row = new QSurfaceDataRow(stepsX);
        float y = float(yMin + j * stepY);

        for (int i = 0; i < stepsX; ++i) {
            float x = float(xMin + i * stepX);

            // Utiliser la fonction du modèle
            float z = float(m_model->evaluate(x, y));

            (*row)[i].setPosition(QVector3D(x, z, y));
        }

        *dataArray << row;
    }

    // 3) Mise à jour de la série
    m_series->dataProxy()->resetArray(dataArray);
}


MainWindow::~MainWindow()
{
    delete ui;
}
